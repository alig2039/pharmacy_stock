// var hljs = require('highlight.js/lib/index.js')

// export { hljs }
import hljs from 'highlight.js/lib/index';

export { hljs };
