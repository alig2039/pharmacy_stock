(function($){
    "use strict"
    // Standard select boxes
    











})(jQuery);