(function($) {
    "use strict"

    new ClipboardJS('.clipboard-btn');









})(jQuery);