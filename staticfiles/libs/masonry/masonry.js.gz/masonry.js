// var Masonry = require('masonry-layout/dist/masonry.pkgd')

// export { Masonry }

import * as Masonry from 'masonry-layout/dist/masonry.pkgd';

export { Masonry };
